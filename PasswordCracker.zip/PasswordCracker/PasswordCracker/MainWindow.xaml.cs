﻿using PasswordCracker.Models;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;

namespace PasswordCracker
{
    public partial class MainWindow : Window
    {
        private const string PasswordFilePath = "encryptedPassword.txt";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void EncryptButton_Click(object sender, RoutedEventArgs e)
        {
            string password = PasswordTextBox.Text;
            if (!string.IsNullOrEmpty(password))
            {
                string encryptedPassword = PasswordEncryption.EncryptPassword(password);
                ResultTextBox.Text = encryptedPassword;
            }
            else
            {
                StatusTextBlock.Text = "Please enter a password.";
            }
        }

        private async void BruteForceButton_Click(object sender, RoutedEventArgs e)
        {
            string encryptedPassword = ResultTextBox.Text;
            if (!string.IsNullOrEmpty(encryptedPassword))
            {
                if (int.TryParse(MaxThreadsTextBox.Text, out int maxThreads) && maxThreads > 0)
                {
                    int logicalProcessors = Environment.ProcessorCount;
                    if (maxThreads > logicalProcessors)
                    {
                        maxThreads = logicalProcessors;
                        StatusTextBlock.Text = $"Max threads set to logical processors limit: {logicalProcessors}";
                    }

                    ProgressBar.Value = 0;
                    StatusTextBlock.Text = "Starting brute force attack...";
                    var progress = new Progress<int>(value => ProgressBar.Value = value);
                    var result = await BruteForce.CrackPasswordAsync(encryptedPassword, maxThreads, progress);
                    StatusTextBlock.Text = result.Item1 != null ? $"Password found: {result.Item1}" : "Password not found.";
                    TimeTextBlock.Text = $"Time taken: {result.Item2} ms";
                }
                else
                {
                    StatusTextBlock.Text = "Please enter a valid number of threads.";
                }
            }
            else
            {
                StatusTextBlock.Text = "Please encrypt a password first.";
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string encryptedPassword = ResultTextBox.Text;
            if (!string.IsNullOrEmpty(encryptedPassword))
            {
                File.WriteAllText(PasswordFilePath, encryptedPassword);
                StatusTextBlock.Text = "Encrypted password saved to file.";
            }
            else
            {
                StatusTextBlock.Text = "No encrypted password to save.";
            }
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists(PasswordFilePath))
            {
                string encryptedPassword = File.ReadAllText(PasswordFilePath);
                ResultTextBox.Text = encryptedPassword;
                StatusTextBlock.Text = "Encrypted password loaded from file.";
            }
            else
            {
                StatusTextBlock.Text = "No saved password file found.";
            }
        }
    }
}
